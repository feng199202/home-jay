package com.tarena.netctoss.util;

public class SessionContact {
	//普通用户对象的session
	public static final String SESSION_USER="userAccount";
	
}
